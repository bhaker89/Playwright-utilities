const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');

function loadYaml(filePath) {
  if (!fs.existsSync(filePath)) {
    return null;
  }

  return yaml.load(fs.readFileSync(filePath, 'utf8'));
}

function loadServiceRegistry(service, feature) {
  if (!service || !feature) {
    return null;
  }

  const registryPath = path.join(
    process.cwd(),
    'locator-registry',
    'services',
    service,
    `${feature}.yaml`
  );

  return loadYaml(registryPath);
}

function loadGlobalRegistry(feature) {
  const registryPath = path.join(
    process.cwd(),
    'locator-registry',
    'global',
    `${feature}.yaml`
  );

  return loadYaml(registryPath);
}

module.exports = {
  loadServiceRegistry,
  loadGlobalRegistry,
};